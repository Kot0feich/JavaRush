package com.javarush.task.task25.task2515;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Space {
    private int width;

    public int getWidth() {
        return width;
    }

    private int height;

    public int getHeight() {
        return height;
    }

    private SpaceShip ship;

    public SpaceShip getShip() {
        return ship;
    }

    public void setShip(SpaceShip ship) {
        this.ship = ship;
    }

    private List<Ufo> ufos = new ArrayList<>();

    public List<Ufo> getUfos() {
        return ufos;
    }

    private List<Rocket> rockets = new ArrayList<>();

    public List<Rocket> getRockets() {
        return rockets;
    }

    private List<Bomb> bombs = new ArrayList<>();

    public List<Bomb> getBombs() {
        return bombs;
    }

    public Space(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void run () {}
    public void draw() {}
    public void sleep(int ms) {}

    public static Space game;
    public List<BaseObject> getAllItems () {
        List<BaseObject> objects = new ArrayList<>();
        objects.add(ship);
        objects.addAll(ufos);
        objects.addAll(rockets);
        objects.addAll(bombs);
        return objects;
    }
    public void moveAllItems () {
       /* ship.move();
        Iterator<Ufo> ufoIterator = ufos.iterator();
        while (ufoIterator.hasNext()) ufoIterator.next().move();
        Iterator<Rocket> rocketIterator = rockets.iterator();
        while (rocketIterator.hasNext()) rocketIterator.next().move();*/
        for (BaseObject object : getAllItems()) {
            object.move();
        }
    }
    public void createUfo() {
        if (ufos.size()==0) ufos.add(new Ufo(getWidth()/2,0));
    }

    public void checkBombs() {
        for (Bomb bomb : bombs) {
            if (bomb.isIntersect(ship)) {
                bomb.die();
                ship.die();
            }
            if (bomb.getY()>height) bomb.die();
        }
    }
    public void checkRockets() {
        for (Rocket rocket: rockets) {
            for (Ufo ufo : ufos) {
                if (ufo.isIntersect(rocket)) {
                    rocket.die();
                    ufo.die();
                }
            }
            if (rocket.getY()<0) rocket.die();
        }
    }

    public void removeDead() {
        Iterator<Ufo> ufoIterator = ufos.iterator();
        while (ufoIterator.hasNext()) {
            if (!ufoIterator.next().isAlive()) ufoIterator.remove();
        }
        Iterator<Rocket> rocketIterator = rockets.iterator();
        while (rocketIterator.hasNext()) {
            if (!rocketIterator.next().isAlive()) rocketIterator.remove();
        }
        Iterator<Bomb> bombIterator = bombs.iterator();
        while (bombIterator.hasNext()) {
            if (!bombIterator.next().isAlive()) bombIterator.remove();
        }
    }






    public static void main(String[] args) {

    }
}

package com.javarush.task.task25.task2515;

public class Bomb extends BaseObject {
    double x,y;
    public Bomb(double x, double y) {
        super(x, y, 1);
    }

    public void move() {
        y = getY();
        setY(y+1);
    }

    public void draw(Canvas canvas) {
        x=getX();
        y=getY();
        canvas.setPoint(x,y,'B');
    }
}
